#This Organizes the specified sub calls for each ANSYS build step
import numpy as np
from ansys.mapdl.core import launch_mapdl
import CGeometry
import CMesh
import CProperties
import CResults

Nside = 5;#Number of servos per side
Servo_width = 0.01#size of each servo area
DeviceWidth = 1;
Cell_width = DeviceWidth/Nside;
thickness = 0.01

def main(mapdl):
    try:
        # Build plate Geometry wit specfied faces
        cellinfo,servo_area_ids = CGeometry.platebuilder(mapdl,DeviceWidth,Nside,Servo_width,Cell_width,thickness=thickness)
        CMesh.platemesh(mapdl,servo_area_ids, thickness=thickness)
        CProperties.properties_and_BC(mapdl,servo_area_ids)

        # Solve the Static Problem
        # ~~~~~~~~~~~~~~~~~~~~~~~~
        # Solve the static analysis
        mapdl.run("/SOLU")
        mapdl.antype("STATIC")
        mapdl.time(1)
        mapdl.solve()
        mapdl.finish(mute=True)

        #Show max Stress
        result = mapdl.result
        result.plot_principal_nodal_stress(
            0,
            "SEQV",
            lighting=False,
            background="w",
            show_edges=True,
            text_color="k",
            add_text=False,
        )

        # Close Mechanical
        mapdl.exit()
    except Exception as e:
        print(f"Caught error: {e}")

        # Close Mechanical
        mapdl.exit()

if __name__ == "__main__":
    # start mapdl (Ansys)
    mapdl = launch_mapdl(run_location=r"C:\Users\damia\OneDrive\Desktop\drive\School Vault\RIT\Research\Ansys\MAPDL_FILES", additional_switches="-m 12000",loglevel="INFO",override=True)  # 12 GB memory

    main(mapdl)

    # Close Mechanical
    mapdl.exit()