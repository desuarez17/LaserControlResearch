#This Organizes the specified sub calls for each ANSYS build step
import numpy as np
from ansys.mapdl.core import launch_mapdl
import CGeometry
import CMesh
import CProperties
import CResults

Nside = 5;#Number of servos per side
Servo_width = 0.02#size of each servo area
DeviceWidth = 1;
Cell_width = DeviceWidth/Nside;
thickness = 0.05

def main(mapdl):
    try:
        mapdl.prep7()
        mapdl.blc5(0, 0, width=DeviceWidth, height=DeviceWidth, depth=thickness)  # main area



        mapdl.et(1,"SHELL186")

        mapdl.mshkey(0)
        mapdl.mshape(1,"3D")
        #mapdl.SMRT(6)
        mapdl.vsweep("all")
        mapdl.eplot(vtk=True, show_edges=True, show_axes=False, line_width=2, background="w")

        mapdl.units("SI")  # SI - International system (m, kg, s, K).

        # Define a material (nominal steel in SI)
        mapdl.mp("EX", 1, 210e9)  # Elastic moduli in Pa (kg/(m*s**2))
        mapdl.mp("DENS", 1, 7800)  # Density in kg/m3
        mapdl.mp("NUXY", 1, 0.3)  # Poisson's Ratio

        base_id = 1
        # Select base plate area (outer frame)
        mapdl.asel("S", "AREA", "", base_id)
        mapdl.lsla("S")  # Lines around the base
        mapdl.nsll("S", 1)  # Nodes on those lines
        mapdl.nsel("R", "LOC", "Z", 0)  # Restrict to bottom face nodes

        # Apply boundary condition (fixed in Z)
        mapdl.d("ALL", "UZ", 0)

        tol = 1e-4
        x_center = DeviceWidth / 2
        y_center = DeviceWidth / 2
        z_top = thickness
        mapdl.nsel("S", "LOC", "X", x_center - tol, x_center + tol)
        mapdl.nsel("R", "LOC", "Y", y_center - tol, y_center + tol)
        mapdl.nsel("R", "LOC", "Z", z_top - tol, z_top + tol)



        #solve1
        mapdl.run("/SOLU")
        mapdl.antype("STATIC")
        mapdl.time(1)
        mapdl.solve()
        mapdl.finish(mute=True)

        # Show max Stress
        result = mapdl.result
        result.plot_principal_nodal_stress(
            0,
            "SEQV",
            lighting=False,
            background="w",
            show_edges=True,
            text_color="k",
            add_text=False,
        )

        mapdl.exit()
    except Exception as e:
        print(f"Caught error: {e}")

        # Close Mechanical
        mapdl.exit()

if __name__ == "__main__":
    # start mapdl (Ansys)
    mapdl = launch_mapdl(run_location=r"C:\Users\damia\OneDrive\Desktop\drive\School Vault\RIT\Research\Ansys\MAPDL_FILES", additional_switches="-m 12000",loglevel="INFO")  # 12 GB memory

    main(mapdl)

    # Close Mechanical
    mapdl.exit()